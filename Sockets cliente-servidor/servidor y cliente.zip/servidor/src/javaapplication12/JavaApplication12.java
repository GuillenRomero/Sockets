
package javaapplication12;
import java.net.*;
import java.io.*;

public class JavaApplication12 {

    public static void main(String[] args)  {
        ServerSocket socketServidor=null;
        Socket socket=null;
       
        try{
        socketServidor = new ServerSocket (Integer.valueOf(args[0]));
        if(Integer.valueOf(args[0])<=2000){
            System.out.println("puerto utilizado");
            System.exit(0);
        }
        socket = socketServidor.accept();
        }
        catch(NumberFormatException e){
            
            System.out.println("no ingreso puerto numerico"); 
            System.exit(0);
        }
       catch(IOException e)
        {
            System.out.println("Error al crear el servidor");
                System.exit(0);
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("nesesita poner un espacio antes del puerto");  
                System.exit(0);
        }
        catch(NullPointerException e)
        {
            System.out.println("El puerto esta nulo");
                System.exit(0);
        }
    
        try{
        BufferedReader entrada= new BufferedReader( new InputStreamReader(socket.getInputStream()));
          String info=null;
        while((info=entrada.readLine())!=null){
            
                System.out.println("me dijeron que "+info);
        }
        }
        catch(IOException e)
        {
            System.out.println("Error al acceder al buffer");
        }
      
    }
    
}
