/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ejemplocliente2;
import java.io.*;
import java.net.*;
/**
 *
 * @author ITLM
 */
public class EjemploCliente2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        // TODO code application logic here
        
        Socket socket=null;
        try{
        //socket = new Socket("127.0.0.1",2500);
            socket = new Socket(args[0], Integer.parseInt(args[1]));
            if(Integer.valueOf(args[1])<=2000){
            System.out.println("puerto utilizado");
            System.exit(0);
        }
        
        }
        catch(NumberFormatException e)
        {
            System.out.println("puerto no numerico");
        }
          catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("nesesita poner un espacio antes de la IP ");  
                System.exit(0);
        }
        catch (IOException e){
            System.out.println(" no puede llegear al host");
        }
        
        try{
        PrintWriter escritor = new PrintWriter(socket.getOutputStream(), true);

        escritor.println(args[args.length-1]);
         socket.close();
        }
        catch(IOException e){
            System.out.println("error a enviar el mensaje");
            System.exit(1);
        }
        
       
    }
    
}
