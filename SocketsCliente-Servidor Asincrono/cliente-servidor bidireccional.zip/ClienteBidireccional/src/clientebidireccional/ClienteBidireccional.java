
package clientebidireccional;
import java.io.*;
import java.net.*;
import java.util.Scanner;

public class ClienteBidireccional {

    
    public static void main(String[] args){
        Socket socket=null;
        String ip="";
        int puerto=-1;
        if(!args[0].isEmpty()){
            ip=args[0];
        }else{
            System.out.println("No ingreso ip");
        }
        if(!args[1].isEmpty()){
            try {
                puerto=Integer.valueOf(args[1]);
            } catch (NumberFormatException e) {
                System.out.println("Error al convertit el numero de puerto\nNo fue ingresado un numero");
            }
        }else{
            System.out.println("No ingreso puerto");
        }
            
        try{
          socket = new Socket(ip,puerto);         
        }catch(IOException e){
            System.out.println("Error al crear el socket "+e.toString()); 
            System.exit(0);
        }
        PrintWriter escritor=null;
        try{
         escritor= new PrintWriter(
            socket.getOutputStream(),true);  
        }catch(IOException e){
            System.out.println("Error al crear el escritor "+e.toString());
            System.exit(1);
        }
        BufferedReader lector=null;
        try{
          lector = new BufferedReader(
          new InputStreamReader(socket.getInputStream())
        );  
        }catch(IOException e){
            System.out.println("Error al crear el lector "+e.toString());
            System.exit(2);
        }
        String datos="";
        String datosEntrada;
        Scanner scanner= new Scanner(System.in);
        
        do{
         try{
          datos=scanner.nextLine();
          escritor.println(datos);
         }catch(NullPointerException e){
             System.out.println("Error al leer los datos "+e.toString());
             System.exit(3);
         }
          try{
          if(datos.equalsIgnoreCase("fin")){
              socket.close();
              System.exit(4);
          }
          }catch(IOException e){
              System.out.println("Error al cerrar el socket "+e.toString());
              System.exit(5);
          }
          try{
          datosEntrada=lector.readLine();
          System.out.println(datosEntrada);
          }catch(IOException e){
              System.out.println("Error al enviar los datos "+e.toString());
              System.exit(6);
          }
        }while(!datos.equalsIgnoreCase("fin"));
    }
    
}
