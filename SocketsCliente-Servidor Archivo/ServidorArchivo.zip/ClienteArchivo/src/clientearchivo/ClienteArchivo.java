/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package clientearchivo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Mando
 */
public class ClienteArchivo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)  {
        // TODO code application logic here
        String teclado;
        String teclado1;
        int len;
        long rec=0;
        long porc;
        long aux=0;
        Scanner scanner =null;
         Socket socket=null;
         PrintWriter escritor=null;
         BufferedReader lector=null;
         BufferedInputStream  bis=null;
         BufferedOutputStream bos=null; 
         
        try{
             // Seprepara el socket con la IP y el puerto
            socket = new Socket(args[0], Integer.parseInt(args[1]));
            //comprobacion para que el puerto sea mayor a 2000
            if(args[0]!=null && Integer.parseInt(args[1])<=2000){
            System.out.println("puerto utilizado");
            System.exit(0);
        }
        
        }
        catch(NumberFormatException e)
        {
            System.out.println("puerto no numerico");
            System.exit(0);
        }
          catch(ArrayIndexOutOfBoundsException e)
        {
                  System.out.println("Error,en el formato de IP y puerto");
         
            System.out.println("formato " +"IP" +" Puerto");  
                System.exit(0);
        }
        catch (IOException e){
            System.out.println(" no puede llegear al host");
            System.exit(0);
        }
        
    
  
    try{
     while(true){
       
         
            if ( socket.isConnected()==true)
            {
                System.out.println("Esta conectado");
            }
             scanner = new Scanner (System.in);
     //creaccion del escritor y lector para la conversacion con el servidor
             escritor = new PrintWriter (socket.getOutputStream(),true);
             lector = new BufferedReader( new InputStreamReader (socket.getInputStream()) );
      
            System.out.println();
            System.out.println("Ingrese la ruta del archivo que quiere resivir: " );
            //Guardamos los datos de la consola
            teclado1=scanner.nextLine();
             System.out.println();
            System.out.println("Ingrese la ruta y archivo donde desea escribir: " );
            //Guardamos los datos de la consola esta vez con la direccion donde se guardara el archivo
            teclado=scanner.nextLine();
            //Mandamos la primera ruta para comprobar de que exista en el servidor
            escritor.println(teclado1);
           
              //Comprobacion de que el archivo que pedimos existe
            if(lector.toString().equalsIgnoreCase("Archivo no existe"))
            {
                System.out.print("El archivo que busca no existe");
                System.exit(0);
            }
              //se gurda el tamaño del archivo 
            int result = Integer.parseInt(lector.readLine());
            //Se crea un nuevo archivo con el nombre obtenida del servidor
             File nombre= new File(lector.readLine());
               //se crea un nuevo archivo el cual contendra la direccion pedida mas el nombre del archivo original
            File file = new File(teclado+nombre);
              //Comprobacion para ver si el archivo existe en caso qe no lo crea
            if(!file.exists())
            {
                try{
          file.createNewFile();
            }
            catch(IOException e){
                System.out.println("Error al crear el archivo ");
            }
            }
            else if(file.exists())
            {
                System.out.print("El archivo ya existe");
            }
            
         try{
             
          bos = new BufferedOutputStream(new  FileOutputStream(file));   
          bis = new BufferedInputStream(new FileInputStream(teclado1));    

      //creacion de buffer con un tamaño de 1024
        byte buffer[] = new byte[1024];
     System.out.println("El tamaño del archivo es: "+result);
        long tamaño=result ;
        long tama=76;
        //Agregacion de datos el nuevo archivo
      while ((len = bis.read(buffer)) != -1){
            bos.write(buffer,0,len);
           //creaccion de la barra de progreso 
            rec=len + rec;
            porc=(rec*100)/tamaño;
            if(aux !=porc){
                for(long y=0; y <tama +10;y++)
                {
                    System.out.print("\b");
                }
                System.out.print("[");
                long pintar =(tama*((100*rec) / tamaño))/100;
                for(long y=0; y < pintar+1; y ++)
                {
                    System.out.print("█");
                }
                for(long y =0; y < tama - pintar; y++)
                { 
                    System.out.print("_");
                }
                System.out.print("]");
                System.out.print(porc+"%");
                        aux=porc;
            }
            else if(aux==0)
            {
                aux=1;
            }
        }

      bos.close();
      bis.close();
        }
        catch(IOException e)
        {
            System.out.print("Error al Cerrar el buffer");
        }

    
    }
    }
    catch(IOException e)
    {
         if(e.toString().equals("java.net.SocketException: Connection reset")){
              System.out.println("El servidor se desconecto");}
         else{
                System.err.println(e);
                System.out.println("Ocurrio : " + e.toString());
            }
             if(e.toString().equals("java.net.SocketException: software caused connection abort : recv failed")){
              System.out.println("El servidor se desconecto");}
    }
    
    }   
}
