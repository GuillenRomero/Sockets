/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package servidorarchivo;

import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.Scanner;

/**
 *
 * @author Mando
 */
public class ServidorArchivo {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args)throws Exception {
        // TODO code application logic here
        do{
         ServerSocket socketServidor = null;
         PrintWriter escritor=null;
         BufferedReader lector =null;
         BufferedOutputStream bos =null;
         BufferedInputStream  bis=null;
         Socket socket=null;
          File archivo=null;
 
              try{
        socketServidor = new ServerSocket (Integer.valueOf(args[0]));
        
        if(Integer.valueOf(args[0])<=2000){
            System.out.println("puerto utilizado");
            System.exit(0);
        }
        socket = socketServidor.accept();
     
        }
        catch(NumberFormatException e){
            
            System.out.println("Error en el formato,puerto solo numerico"); 
            System.exit(0);
        }
       catch(IOException e)
        {
            System.out.println("Error al crear el servidor");
                System.exit(0);
        }
        catch(ArrayIndexOutOfBoundsException e)
        {
            System.out.println("Error,no se a ingresado puerto");  
                System.exit(0);
        }
        catch(NullPointerException e)
        {
            System.out.println("NO se logro la coneccion con el cliente");
                System.exit(0);
        }
             
             try{ 
          
              lector = new BufferedReader( new InputStreamReader (socket.getInputStream()));
              escritor = new PrintWriter (socket.getOutputStream(),true);
              System.out.println("Cliente conectado");
                      
             archivo = new File( lector.readLine());
            if(archivo!=null){
                
              if(archivo.exists()==false)
              {
                  System.out.println("El archivo que pide el cliente no existe");
                  escritor.println("Archivo no existe");   
              }

             escritor.println(archivo.length());
             escritor.println(archivo.getName());
             int len;

             bos = new BufferedOutputStream(socket.getOutputStream());
             bis = new BufferedInputStream(new FileInputStream(archivo));
  
             DataInputStream is = new DataInputStream(socket.getInputStream());
             byte buffer[] = new byte[1024];
        
             while((len = bis.read(buffer)) != -1) {
	     bos.write(buffer, 0, len);}
                 
             bos.close();
             bis.close();
            socketServidor.close();
           }
            else{
                System.out.print("La ruta especificada por el cliente no existe");
            }
             }
             
    catch(IOException e){
        System.out.println("Error con el archivo");
        
        
    }
    
        }while (true);
    }
}
