package recibirarchivoservidor;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.EOFException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.net.Socket;
import java.util.Scanner;
import java.util.logging.Level;
import java.util.logging.Logger;
 

     public class RecibirArchivoServidor {
 
    private File archivo = null;
    private BufferedWriter bw = null;
    private Socket cliente = null;
    private String nombreFichero = null;
    private Scanner sca = null;
    private DataInputStream dis = null;
    private DataOutputStream dos = null;
    private boolean existeFichero = false;
    private boolean terminado = false;
 
        public RecibirArchivoServidor() {
 
        try {
            cliente = new Socket("localhost", 6565);
            dis = new DataInputStream(cliente.getInputStream());
            dos = new DataOutputStream(cliente.getOutputStream());
            sca = new Scanner(System.in);
            do {
 
                System.out.println("Escribe la ruta y el archivo");
                nombreFichero = sca.nextLine();
                //Manda el nombre del archivo
                dos.writeUTF(nombreFichero);
                existeFichero = dis.readBoolean();
                if(!existeFichero){
                    System.out.println("El archivo no existe");
                }
            }while(existeFichero ==false);
                //crea el nuevo archivo
            File archivo= new File("nuevo.txt");
            archivo.createNewFile();
          
            BufferedOutputStream bos = new BufferedOutputStream(new FileOutputStream(archivo));
            int lee;
            while((lee = dis.readByte()) != 1) {
                bos.write(lee);
            }
            bos.close();
            cliente.close();
            sca.close();
            //leemos lo que tiene el nuevo archivo 
            BufferedReader br = new BufferedReader(new FileReader("nuevo.txt"));
            String linea;
            System.out.println("el archivo se guardo el C:\\Users\\(usuario)\\");
            while((linea=br.readLine()) != null) {
                System.out.println(linea);
            }

        } catch (IOException ex) {
 
            System.out.println(ex.getMessage());
            System.out.println(ex.toString());        }
 
    }
 
 
    public static void main(String[] args) {
 
        new RecibirArchivoServidor();
 
    }
 
}