package mandararchivocliente;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.DataOutputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.FileReader;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;
import java.util.logging.Level;
import java.util.logging.Logger;
 

public class MandarArchivoCliente {
 
    private ServerSocket servidor = null;
    private Socket cliente = null;
    private FileReader fr = null;
    private BufferedReader br = null;
    private String rutaFichero = null;
    private DataOutputStream dos = null;
    private DataInputStream dis = null;
    private File archivo = null;
    private boolean existeFichero = false;
    private boolean archivoTerminado = false;
 
    public MandarArchivoCliente(){
 
 
        try {
            servidor = new ServerSocket(6565);
            cliente = servidor.accept();
            dis = new DataInputStream(cliente.getInputStream());
            dos = new DataOutputStream(cliente.getOutputStream());
 
         do {
                //recive la ruta
                rutaFichero = dis.readUTF();
                archivo = new File(rutaFichero);
                if(archivo.exists()) {
                  //verifica si existe
                    dos.writeBoolean(true);
                    existeFichero = true;
                }else {
                    dos.writeBoolean(false);
                    existeFichero = false;
                }
 
            }while(existeFichero == false);

            //buffer para enviar los datos del archivo
            BufferedInputStream bis = new BufferedInputStream(new FileInputStream(archivo));
            int leer;
 
            while((leer = bis.read()) != -1) {
                //mandar los datos 
                dos.writeByte(leer);
            }
 
            bis.close();
            dos.writeBoolean(true);
            servidor.close();
            cliente.close();
 
        } catch (IOException ex) {
 
            System.out.println(ex.getMessage());
        }
    }
 
 
    public static void main(String[] args) {
 
        new MandarArchivoCliente();
 
    }
 
}